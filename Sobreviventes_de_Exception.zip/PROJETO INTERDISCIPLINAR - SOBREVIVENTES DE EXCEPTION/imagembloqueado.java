import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class imagembloqueado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class imagembloqueado extends Actor
{
   public imagembloqueado(){
    setImage("Imagemblock.png");
    }
}
