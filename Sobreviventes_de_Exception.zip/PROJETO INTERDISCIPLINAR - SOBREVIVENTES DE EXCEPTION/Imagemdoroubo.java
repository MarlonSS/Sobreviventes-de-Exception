import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Imagemdoroubo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Imagemdoroubo extends Actor
{
    public void Imagemdoroubo(){
        setImage("imagem3.png");
    }
    
    

}
